export const datafields = {
    aboutus: "It is a long established fact that a reader will be distracted by the",
    servicelist: ["SEO","BRANDING", "LOGO"],
    seo: "It is a long established fact that a reader will be distracted by the",
    branding: "It is a long established fact that a reader will be distracted by the",
    logo: "It is a long established fact that a reader will be distracted by the"
}